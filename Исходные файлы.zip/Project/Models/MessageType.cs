﻿namespace Project.Models
{
    public enum MessageType
    {
        Info = 0,
        Error = 1,
        Warning = 2,
        Success = 3
    }
}
